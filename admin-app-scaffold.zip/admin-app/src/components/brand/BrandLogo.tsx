interface BrandLogoProps { className?: string; showWordmark?: boolean; }
export function BrandLogo({ className, showWordmark = true }: BrandLogoProps) {
  return (
    <div className={['inline-flex items-center gap-3', className].filter(Boolean).join(' ')}>
      <img src="/assets/brand/logo-monogram.svg" alt="KTMS" className="h-10 w-9" />
      {showWordmark && <span className="font-semibold tracking-[0.18em] text-ice">KTMS</span>}
    </div>
  );
}
