import type { TextareaHTMLAttributes } from 'react';
export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) { return <textarea {...props} className={`min-h-28 w-full rounded-lg border border-steel bg-charcoal p-3 text-base text-ice placeholder:text-silver focus:border-cyan focus:outline-none ${props.className ?? ''}`} />; }
