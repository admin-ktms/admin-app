import type { ReactNode } from 'react';
export interface DataTableColumn<T> { key: string; header: string; render: (row: T) => ReactNode; }
interface DataTableProps<T> { columns: DataTableColumn<T>[]; rows: T[]; getRowKey: (row: T) => string; emptyMessage?: string; }
export function DataTable<T>({ columns, rows, getRowKey, emptyMessage = 'No records found.' }: DataTableProps<T>) {
  if (!rows.length) return <div className="rounded-xl border border-steel bg-charcoal p-8 text-center text-silver">{emptyMessage}</div>;
  return <div className="overflow-x-auto rounded-xl border border-steel"><table className="w-full border-collapse text-left text-sm"><thead className="bg-charcoal text-silver"><tr>{columns.map(c => <th key={c.key} className="px-4 py-3 font-medium">{c.header}</th>)}</tr></thead><tbody>{rows.map(row => <tr key={getRowKey(row)} className="border-t border-steel bg-stadium">{columns.map(c => <td key={c.key} className="min-h-12 px-4 py-3">{c.render(row)}</td>)}</tr>)}</tbody></table></div>;
}
