import type { ReactNode } from 'react';
interface StatusBadgeProps { children: ReactNode; tone?: 'neutral' | 'success' | 'warning' | 'danger'; }
const tones = { neutral: 'bg-steel text-ice', success: 'bg-victory/15 text-victory', warning: 'bg-gold/15 text-gold', danger: 'bg-coral/15 text-coral' };
export function StatusBadge({ children, tone = 'neutral' }: StatusBadgeProps) { return <span className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold ${tones[tone]}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{children}</span>; }
