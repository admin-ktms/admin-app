import type { ButtonHTMLAttributes, ReactNode } from 'react';
type Variant = 'primary' | 'secondary' | 'danger' | 'ghost';
interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> { variant?: Variant; children: ReactNode; }
const styles: Record<Variant, string> = {
  primary: 'bg-cyan text-midnight hover:brightness-110',
  secondary: 'border border-steel bg-stadium text-ice hover:border-cyan',
  danger: 'bg-coral text-midnight hover:brightness-110',
  ghost: 'bg-transparent text-ice hover:bg-stadium',
};
export function Button({ variant = 'primary', className = '', children, ...props }: ButtonProps) {
  return <button className={`min-h-touch rounded-lg px-4 py-2 font-semibold transition ${styles[variant]} disabled:cursor-not-allowed disabled:opacity-50 ${className}`} {...props}>{children}</button>;
}
