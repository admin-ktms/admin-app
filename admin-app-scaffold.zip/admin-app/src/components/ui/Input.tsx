import type { InputHTMLAttributes } from 'react';
export function Input(props: InputHTMLAttributes<HTMLInputElement>) { return <input {...props} className={`min-h-touch w-full rounded-lg border border-steel bg-charcoal px-3 text-base text-ice placeholder:text-silver focus:border-cyan focus:outline-none ${props.className ?? ''}`} />; }
