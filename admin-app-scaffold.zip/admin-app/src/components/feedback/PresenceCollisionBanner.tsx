interface PresenceCollisionBannerProps { names: string[]; }
export function PresenceCollisionBanner({ names }: PresenceCollisionBannerProps) { if (!names.length) return null; return <div role="status" className="rounded-lg border border-gold/40 bg-gold/10 p-3 text-sm text-gold">Other staff may be reviewing this case: {names.join(', ')}. Coordinate before making changes.</div>; }
