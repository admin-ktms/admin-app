interface EmptyStateProps { title: string; description?: string; }
export function EmptyState({ title, description }: EmptyStateProps) { return <div className="rounded-xl border border-dashed border-steel bg-charcoal p-8 text-center"><h2 className="font-semibold text-ice">{title}</h2>{description && <p className="mt-2 text-sm text-silver">{description}</p>}</div>; }
