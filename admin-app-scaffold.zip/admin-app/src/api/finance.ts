// Backend calls only. Financial mutations require verified KTMS contracts and audit controls.
export {};
