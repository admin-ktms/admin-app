// Backend calls only. Sanctions require verified role checks and audit records.
export {};
