import { EmptyState } from '@/components/feedback/EmptyState';

export function AccessDeniedView() {
  return <section className="space-y-4"><div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan">KTMS Administration</p><h1 className="mt-2 text-2xl font-bold">Access denied</h1></div><EmptyState title="Module scaffold ready" description="This account is not authorized to access the administration console. This view is a scaffold only; no database mutation is wired." /></section>;
}
