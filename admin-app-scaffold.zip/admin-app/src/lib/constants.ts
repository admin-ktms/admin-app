export const APP_TIME_ZONE = 'Africa/Lagos';
export const DEFAULT_PAGE_SIZE = 25;
export const MAX_PAGE_SIZE = 100;

export const ROUTE_PATHS = {
  login: '/login',
  dashboard: '/',
  tournaments: '/tournaments',
  disputes: '/adjudication',
  finance: '/finance',
  disciplinary: '/disciplinary',
  support: '/support',
  achievements: '/achievements',
  governance: '/governance',
} as const;
