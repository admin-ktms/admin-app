export interface KeyValueStorage {
  get(key: string): Promise<string | null>;
  set(key: string, value: string): Promise<void>;
  remove(key: string): Promise<void>;
}

export const webStorage: KeyValueStorage = {
  async get(key) { return window.localStorage.getItem(key); },
  async set(key, value) { window.localStorage.setItem(key, value); },
  async remove(key) { window.localStorage.removeItem(key); },
};
