// Replace with generated Supabase Database types after schemas/contracts are verified.
export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];
export type Database = { __NotYetGenerated: true };
