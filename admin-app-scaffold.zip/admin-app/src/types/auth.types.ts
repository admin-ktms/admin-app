export type AdminRoleCode = string;

export interface AdminSession {
  userId: string;
  roleCode: AdminRoleCode;
}

export interface Profile {
  id: string;
  displayName: string | null;
}
