export type TableDensity = 'compact' | 'touch';
export const DEFAULT_TABLE_DENSITY: TableDensity = 'touch';
