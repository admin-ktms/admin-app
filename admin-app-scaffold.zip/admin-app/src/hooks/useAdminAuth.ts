// TODO: implement fail-closed session bootstrap against verified KTMS identity resolution.
export {};
