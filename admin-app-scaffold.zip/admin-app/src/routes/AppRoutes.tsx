import { Navigate, Route, Routes } from 'react-router-dom';
import { ProtectedRoute } from '@/routes/ProtectedRoute';
import { AdminShell } from '@/components/layout/AdminShell';
import { LoginView } from '@/views/auth/LoginView';
import { AcceptInviteView } from '@/views/auth/AcceptInviteView';
import { AccessDeniedView } from '@/views/auth/AccessDeniedView';
import { DashboardOverview } from '@/views/dashboard/DashboardOverview';
import { TournamentsListDesk } from '@/views/tournaments/TournamentsListDesk';
import { TournamentDetailDesk } from '@/views/tournaments/TournamentDetailDesk';
import { DisputeQueueDesk } from '@/views/adjudication/DisputeQueueDesk';
import { DisputeReviewCase } from '@/views/adjudication/DisputeReviewCase';
import { BankTransferDesk } from '@/views/finance/BankTransferDesk';
import { AwardDisbursementDesk } from '@/views/finance/AwardDisbursementDesk';
import { PlayerRegistryDesk } from '@/views/disciplinary/PlayerRegistryDesk';
import { PlayerDetailDesk } from '@/views/disciplinary/PlayerDetailDesk';
import { SupportTicketDesk } from '@/views/support/SupportTicketDesk';
import { SupportCaseView } from '@/views/support/SupportCaseView';
import { AchievementMediaReviewDesk } from '@/views/achievements/AchievementMediaReviewDesk';
import { AchievementCurationDesk } from '@/views/achievements/AchievementCurationDesk';
import { StaffDirectoryDesk } from '@/views/governance/StaffDirectoryDesk';
import { ApprovalsDesk } from '@/views/governance/ApprovalsDesk';
import { ArchiveExplorerDesk } from '@/views/governance/ArchiveExplorerDesk';
import { AuditExplorerDesk } from '@/views/governance/AuditExplorerDesk';
const pages = [
  ['/tournaments', TournamentsListDesk], ['/tournaments/:tournamentId', TournamentDetailDesk],
  ['/adjudication', DisputeQueueDesk], ['/adjudication/:caseId', DisputeReviewCase],
  ['/finance/transfers', BankTransferDesk], ['/finance/awards', AwardDisbursementDesk],
  ['/disciplinary', PlayerRegistryDesk], ['/disciplinary/:playerId', PlayerDetailDesk],
  ['/support', SupportTicketDesk], ['/support/:caseId', SupportCaseView],
  ['/achievements/media', AchievementMediaReviewDesk], ['/achievements/curation', AchievementCurationDesk],
  ['/governance/staff', StaffDirectoryDesk], ['/governance/approvals', ApprovalsDesk],
  ['/governance/archive', ArchiveExplorerDesk], ['/governance/audit', AuditExplorerDesk],
] as const;
export function AppRoutes() { return <Routes><Route path="/login" element={<LoginView />} /><Route path="/accept-invite" element={<AcceptInviteView />} /><Route path="/access-denied" element={<AccessDeniedView />} /><Route path="*" element={<ProtectedRoute><AdminShell><Routes><Route path="/" element={<DashboardOverview />} />{pages.map(([path, Component]) => <Route key={path} path={path.slice(1)} element={<Component />} />)}<Route path="*" element={<Navigate to="/" replace />} /></Routes></AdminShell></ProtectedRoute>} /></Routes>; }
