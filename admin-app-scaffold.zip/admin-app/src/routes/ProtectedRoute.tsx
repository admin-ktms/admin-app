import type { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
// Fail closed until the real auth hook and verified staff identity contract are implemented.
export function ProtectedRoute({ children }: { children: ReactNode }) { return <Navigate to="/login" replace state={{ reason: 'auth-not-configured' }} />; }
