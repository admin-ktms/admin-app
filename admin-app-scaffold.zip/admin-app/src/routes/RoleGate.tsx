import type { ReactNode } from 'react';
interface RoleGateProps { allowedRoles: string[]; currentRole: string | null; children: ReactNode; fallback?: ReactNode; }
export function RoleGate({ allowedRoles, currentRole, children, fallback = null }: RoleGateProps) { return currentRole && allowedRoles.includes(currentRole) ? children : fallback; }
