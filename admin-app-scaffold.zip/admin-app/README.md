# KTMS Admin App scaffold

This repository is a frontend scaffold only. API modules and operational views are intentionally placeholders until KTMS's real database schemas, RPC names, payloads, role codes, and authorization policies are verified.

## Setup

1. Copy `.env.example` to `.env.local`.
2. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to the public project URL and anon/publishable key. Never put a Supabase service-role key in a browser app.
3. Run `npm install`.
4. Run `npm run dev`.

## Security notes

- `ProtectedRoute` deliberately fails closed until the verified admin identity resolution flow is implemented.
- The CSP in `public/_headers` is a baseline and must be tested against the deployed Supabase project, any storage/CDN domains, and Cloudflare Pages behavior before production.
- Do not wire privileged mutations until the corresponding KTMS authorization and audit requirements are verified.
