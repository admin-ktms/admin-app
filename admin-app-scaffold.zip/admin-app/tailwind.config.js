/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        midnight: '#080A0F',
        charcoal: '#11151D',
        stadium: '#1A2230',
        cyan: '#00D9FF',
        gold: '#FFC857',
        ice: '#F5F7FA',
        silver: '#A5AFBF',
        steel: '#2A3342',
        victory: '#42D392',
        coral: '#FF6B75',
      },
      minHeight: {
        touch: '44px',
      },
      minWidth: {
        touch: '44px',
      },
      spacing: {
        safeTop: 'env(safe-area-inset-top)',
        safeRight: 'env(safe-area-inset-right)',
        safeBottom: 'env(safe-area-inset-bottom)',
        safeLeft: 'env(safe-area-inset-left)',
      },
    },
  },
  plugins: [],
};
